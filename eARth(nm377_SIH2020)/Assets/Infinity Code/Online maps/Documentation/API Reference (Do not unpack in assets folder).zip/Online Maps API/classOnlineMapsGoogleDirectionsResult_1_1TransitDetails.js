var classOnlineMapsGoogleDirectionsResult_1_1TransitDetails =
[
    [ "arrival_stop", "classOnlineMapsGoogleDirectionsResult_1_1TransitDetails.html#a0be7bcad47db277003e0f2c4f9f549bd", null ],
    [ "arrival_time", "classOnlineMapsGoogleDirectionsResult_1_1TransitDetails.html#a6727ddb8a4744d8aee3185c83e827deb", null ],
    [ "departure_stop", "classOnlineMapsGoogleDirectionsResult_1_1TransitDetails.html#a6f695d1ad0375a7b83180d468351a1ec", null ],
    [ "departure_time", "classOnlineMapsGoogleDirectionsResult_1_1TransitDetails.html#a554802f4fd68511f982d3c3a0b3f67a2", null ],
    [ "headsign", "classOnlineMapsGoogleDirectionsResult_1_1TransitDetails.html#a371dfc4a897a2519fa58877c9c41fdbb", null ],
    [ "headway", "classOnlineMapsGoogleDirectionsResult_1_1TransitDetails.html#a810edb1cd8c6dc6a613498487236b657", null ],
    [ "line", "classOnlineMapsGoogleDirectionsResult_1_1TransitDetails.html#a12500ea610bafc88cd1f3141f6a3aeb8", null ],
    [ "num_stops", "classOnlineMapsGoogleDirectionsResult_1_1TransitDetails.html#adba24dcb5fb994f42383d511672f5a46", null ]
];
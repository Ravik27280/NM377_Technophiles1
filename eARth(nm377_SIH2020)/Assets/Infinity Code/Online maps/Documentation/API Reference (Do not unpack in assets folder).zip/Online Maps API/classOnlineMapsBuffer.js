var classOnlineMapsBuffer =
[
    [ "StateProps", "structOnlineMapsBuffer_1_1StateProps.html", "structOnlineMapsBuffer_1_1StateProps" ],
    [ "ApplyTile", "classOnlineMapsBuffer.html#a897762c99c67647711bbefa83fea5e33", null ],
    [ "Dispose", "classOnlineMapsBuffer.html#af34558244119e924c738e5712862ec1b", null ],
    [ "bufferPosition", "classOnlineMapsBuffer.html#a5a72694c11a5a216514b060defddb415", null ],
    [ "height", "classOnlineMapsBuffer.html#a3999d869b6378128ca62b62ece400c48", null ],
    [ "map", "classOnlineMapsBuffer.html#a683f8674cb71a450d1c45ec5d101e9c8", null ],
    [ "status", "classOnlineMapsBuffer.html#abe886eccb01c0ee0f19dc1cda655b80f", null ],
    [ "width", "classOnlineMapsBuffer.html#a4d3913eca93a89e515d7b64f83aefb1d", null ],
    [ "topLeftPosition", "classOnlineMapsBuffer.html#a88b619caff0f5f4c37d4a30a6816357c", null ]
];
var classOnlineMapsGooglePlaces =
[
    [ "NearbyParams", "classOnlineMapsGooglePlaces_1_1NearbyParams.html", "classOnlineMapsGooglePlaces_1_1NearbyParams" ],
    [ "RadarParams", "classOnlineMapsGooglePlaces_1_1RadarParams.html", "classOnlineMapsGooglePlaces_1_1RadarParams" ],
    [ "RequestParams", "classOnlineMapsGooglePlaces_1_1RequestParams.html", null ],
    [ "TextParams", "classOnlineMapsGooglePlaces_1_1TextParams.html", "classOnlineMapsGooglePlaces_1_1TextParams" ],
    [ "OnlineMapsFindPlacesRankBy", "classOnlineMapsGooglePlaces.html#affdd17f1ebef22cc71340ef69d70c138", [
      [ "prominence", "classOnlineMapsGooglePlaces.html#affdd17f1ebef22cc71340ef69d70c138af7dcf4a2e0c2d8159278ed77934ddecc", null ],
      [ "distance", "classOnlineMapsGooglePlaces.html#affdd17f1ebef22cc71340ef69d70c138aa74ec9c5b6882f79e32a8fbd8da90c1b", null ]
    ] ],
    [ "FindNearby", "classOnlineMapsGooglePlaces.html#ae2b32f35a4c4e058eb2c9eaa7343fac7", null ],
    [ "FindNearby", "classOnlineMapsGooglePlaces.html#a24f36dc1d7722187df278a465787ca2e", null ],
    [ "FindRadar", "classOnlineMapsGooglePlaces.html#a799f4adcb606e523b32928b6164452ae", null ],
    [ "FindRadar", "classOnlineMapsGooglePlaces.html#a32a1f663bb664d9ebeda9f402061a81a", null ],
    [ "FindText", "classOnlineMapsGooglePlaces.html#aa017a220c9ae26df4d9e680fcd9c47e5", null ],
    [ "FindText", "classOnlineMapsGooglePlaces.html#a54a62d689c1711428c82d79d618f7f3b", null ],
    [ "GetResults", "classOnlineMapsGooglePlaces.html#a56aa08058b1a382be452ab6306a883b9", null ],
    [ "GetResults", "classOnlineMapsGooglePlaces.html#a058b06c1c5105f5e53aa162250828a74", null ]
];
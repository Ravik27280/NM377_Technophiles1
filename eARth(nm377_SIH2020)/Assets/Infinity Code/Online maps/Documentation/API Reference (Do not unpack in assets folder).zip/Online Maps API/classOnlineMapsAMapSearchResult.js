var classOnlineMapsAMapSearchResult =
[
    [ "IndoorData", "classOnlineMapsAMapSearchResult_1_1IndoorData.html", "classOnlineMapsAMapSearchResult_1_1IndoorData" ],
    [ "POI", "classOnlineMapsAMapSearchResult_1_1POI.html", "classOnlineMapsAMapSearchResult_1_1POI" ],
    [ "count", "classOnlineMapsAMapSearchResult.html#a1f9ba647aebf1efd52df7314f1a5f16c", null ],
    [ "info", "classOnlineMapsAMapSearchResult.html#ac714325af9bb046b2f9380087b8a1fc2", null ],
    [ "pois", "classOnlineMapsAMapSearchResult.html#a191612206e9fd4361828bb616b981a1e", null ],
    [ "status", "classOnlineMapsAMapSearchResult.html#a96e15feb87d225439d05e991c724391f", null ]
];